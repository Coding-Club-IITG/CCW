# hey hey CCW coders!!!! look at this silly li'l guide to our match rooms~

![CCW Contest Guide Cover](/api/blog/assets/contest_blog_cover.svg)

hey hey everyone!!!! i put together a quick run-down of how our contest rooms work so yall don't get lost in the arena and know exactly how to fight each other (with code, obviously) and how matches move through their lifecycles!!!! 

![CCW Architecture Overview](/api/blog/assets/6f5e59431c100027a513b3f767f5c154.jpg)

---

### ⚡ The Game Modes (Choose Your Fighter!)

*   **Blitz Mode** ⚡: rapid-fire code-slinging! you get problems revealed one by one and it's a pure race against the clock. first to solve gets the points and moves the match forward!
*   **Arena Mode** 🏟️: much more tactical! all problems are open from the start, but watch out: there is a **LOCKING mechanic** 🔒. once a team solves a problem, they lock it! if you try to reclaim it, it's gonna be a CRITICAL steal. super spicy!
*   **Team Battle** 👥: 3v3 action! grab two of your best coding buddies, share the load, sync your brains, and coordinate to take down the opposition.
*   **Bracket (Knockout)** 🏆: the ultimate tournament mode! and guess what? **any authenticated user can create these now, not just admins!** you get seeded (by CF rating or manually) and fight your way up. brackets are automatically generated and progress in real time!

![Bracket Tournament Structure](/api/blog/assets/9c1ff0b037328968f7ee680a987b7644.jpg)

---

### 🔄 The Contest Lifecycle (The Six Phases of Glory)

every match moves through a series of structured states from the drawing board to the podium! here is what they are:

![Contest Lifecycle Flow](/api/blog/assets/73fae3461f538399bf2062cdf492bfa2.jpg)

#### Phase 1: Creation 📝 (`status: draft`)
the organizer clicks create and configures: the format (1v1, solo-tournament, team, or bracket), the mode (blitz vs arena), problem selection mode (bulk, fine-tuned, or test), duration, and registration settings.

#### Phase 2: Registration 🎟️ (`status: registration`)
the registration window opens. players sign up using their linked Codeforces handles. for team battles, players register with matching team names so they get grouped together. 

#### Phase 3: Provisioning ⚙️ (`status: provisioning`)
*happens right after the registration deadline passes.* 
a background job (`check_start`) checks if there are at least 2 valid teams. if not, the contest gets cancelled. if yes, it fetches the recent Codeforces solve histories of **all** participants, filters them out from the database pool (Bulk Mode), generates the matches/rooms, initializes states in Redis, and schedules the waiting room to open.

#### Phase 4: Waiting Room ⏳ (`status: provisioning` transitioning to `active`)
the waiting room opens. players are presented with a **"Ready Up"** button. teams have a **2-minute** ready timeout to click Ready. if they fail, they are withdrawn and the room gets auto-cancelled! (note: bracket matches bypass this timeout so the tournament is never blockaded).

#### Phase 5: Live Battle ⚔️ (`status: active`)
the timer starts ticking! problems are revealed (one-by-one in Blitz, all at once in Arena). players write code and submit on Codeforces. our background sync worker continuously polls the CF API for new AC verdicts and updates Redis scores, locks, and progress instantly!

![Realtime Data Flow](/api/blog/assets/977fc960ba46c102121e47d70ec2b47a.jpg)

#### Phase 6: Completed 🏆 (`status: completed`)
the contest ends (naturally by time, or via walkover/timeout/forfeit). final results are archived, standings/statistics are generated, and winners/MVPs are declared!

---

### 🛠️ Setting Up (The Do's and Don'ts)

*   **Do** set the **difficulty range** (e.g. Codeforces 800 to 2200) to match your skill level!
*   **Do** customize the **number of problems** so you don't end up in a 6-hour marathon unless you actually want to~
*   **Do** write a fun and descriptive name/description for your room!
*   **Don't** try to use empty or invalid problem sets.
*   **Don't** worry about presets if you are a regular user—presets are for admin templates, but you can set up any custom rating ranges you want!

---

### ⏰ The Rules of the Arena (Readies & Forfeits)

*   **The 2-Minute Ready Check** ⏳: once a match is provisioned, *every single registered player* has exactly **2 minutes** to click that shiny "Ready" button. if even one person is tabbed out making tea... BOOM 💥 the room gets auto-cancelled and deleted. (note: bracket matches skip this ready timeout so you have room to breathe!).
*   **Tab Disconnections** 🔌: if your internet drops or you accidentally close the tab, do not panic! **reconnection is handled automatically** the second you open the page again.
*   **The Forfeit Warning** 💀: BUT if you stay disconnected for more than **90 seconds** during an active match, you will forfeit the match! so do NOT close the page while the battle is raging!
*   **Allow Notifications** 🔔: *this is super duper important!* please click **Allow** on the browser notification prompt when you enter the room. we set up native desktop notifications now! even if you are looking at docs in another window, you'll get a popup the second the match starts, or when someone locks a problem!

---

### ⚖️ The Tie-Breaker (How We Settle Grudges)

what happens if yall end up with the same points at the end? we have a very strict hierarchy to decide who takes the crown:
1.  **Solved Count** 🎯: whoever solved more problems overall wins.
2.  **Speed / Penalty Time** 🕒: if solved count is equal, we look at the time of your last solve (`solveMs`). the faster coder wins the tie-breaker! 👑
3.  **MVPs** 🌟: our results engine automatically calculates a match MVP based on total points contributed and solve speed!

---

### 👀 Spectating & Match Results

*   **All matches are visible to everyone now!** you can share your match link or find completed matches in the history tab.
*   if you didn't participate in the match, you can still view the full dashboard and results! you'll see a clean, neutral "SPECTATED" badge and the raw scores, while the actual participants see their custom VICTORY/DEFEAT labels.

---

okie dokie i think that is everything yall need to know for today! go create some rooms, allow those notifications, and show everyone who the real keyboard warrior is!!!!! 🚀
